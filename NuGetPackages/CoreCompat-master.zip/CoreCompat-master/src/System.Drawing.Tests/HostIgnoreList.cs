﻿namespace MonoTests.System.Drawing
{
    internal static class HostIgnoreList
    {
        public static void CheckTest(string name)
        {
        }
    }
}
