#!/bin/sh
rm -rf libgdiplus

git clone https://github.com/corecompat/libgdiplus --depth 1 --single-branch --branch optional-x11

