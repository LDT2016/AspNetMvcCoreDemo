#!/bin/sh
brew install cask
brew install Caskroom/cask/xquartz
brew install autoconf automake libtool pkg-config glib cairo freetype fontconfig libpng libtiff giflib

