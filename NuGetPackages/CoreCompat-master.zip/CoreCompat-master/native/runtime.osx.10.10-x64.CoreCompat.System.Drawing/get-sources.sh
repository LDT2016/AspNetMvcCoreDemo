#!/bin/sh
rm -rf libgdiplus

git clone https://github.com/mono/libgdiplus --depth 1 --single-branch --branch master

